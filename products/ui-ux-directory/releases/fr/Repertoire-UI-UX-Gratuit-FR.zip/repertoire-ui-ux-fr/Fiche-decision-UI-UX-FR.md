# Fiche de décision UI/UX

Version 1.0 · Français · Joy N. / Joyccelight · 18 novembre 2026

À dupliquer pour chaque projet. Les lignes vides sont des champs à remplir, pas des décisions déjà validées.

## 1. Le projet

- Projet / écran :
- Public et tâche principale :
- Plateforme et framework / versions :
- Contraintes (budget, données, hébergement, appareils) :
- Personne responsable / date :

## 2. Les choix

Pour chaque famille, comparer au plus deux options puis noter un choix, y compris « aucun nouvel outil ».

### Couleurs et thèmes

Quelles paires texte/fond restent lisibles dans les deux thèmes ?

- Option A / URL officielle :
- Option B / URL officielle :
- Décision et raison :
- Version, licence et attribution :
- Coût / contrainte / limite :
- Test réalisé et résultat :
- Test restant / responsable / date :

### Typographie

Les accents, chiffres, libellés longs et conditions d’hébergement conviennent-ils ?

- Option A / URL officielle :
- Option B / URL officielle :
- Décision et raison :
- Version, licence et attribution :
- Coût / contrainte / limite :
- Test réalisé et résultat :
- Test restant / responsable / date :

### Icônes

Les noms existent-ils et les actions importantes gardent-elles leur libellé ?

- Option A / URL officielle :
- Option B / URL officielle :
- Décision et raison :
- Version, licence et attribution :
- Coût / contrainte / limite :
- Test réalisé et résultat :
- Test restant / responsable / date :

### Composants et kits

Quels comportements et quelles mises à jour devrez-vous prendre en charge ?

- Option A / URL officielle :
- Option B / URL officielle :
- Décision et raison :
- Version, licence et attribution :
- Coût / contrainte / limite :
- Test réalisé et résultat :
- Test restant / responsable / date :

### Graphiques de données

Le graphique possède-t-il une légende, des unités et une alternative textuelle ?

- Option A / URL officielle :
- Option B / URL officielle :
- Décision et raison :
- Version, licence et attribution :
- Coût / contrainte / limite :
- Test réalisé et résultat :
- Test restant / responsable / date :

### Illustrations et 3D

L’illustration apporte-t-elle une information plutôt qu’un obstacle au chargement ?

- Option A / URL officielle :
- Option B / URL officielle :
- Décision et raison :
- Version, licence et attribution :
- Coût / contrainte / limite :
- Test réalisé et résultat :
- Test restant / responsable / date :

## 3. Avant intégration

- [ ] URLs et auteurs identifiés ; licence lue pour chaque fichier retenu.
- [ ] Droits de modification, d’hébergement et de livraison au client vérifiés.
- [ ] Coûts, quotas et mentions d’attribution acceptés.
- [ ] Aucun fichier client ni donnée personnelle confié à un service sans accord.
- [ ] Aucun pack tiers aspiré ou redistribué ; aucune utilisation IA contraire à une licence.

## 4. Avant livraison

- [ ] États vide, chargement, erreur et succès examinés.
- [ ] Clavier, focus, zoom et écran étroit testés.
- [ ] Contrastes réels et alternatives textuelles examinés.
- [ ] Poids et chargement mesurés sur le projet, pas repris d’une fiche marketing.
- [ ] Imports, noms d’icônes, API et versions proposés par l’IA vérifiés.

Résultat des essais / lien vers la preuve :

Décision (retenu / à revoir / écarté) :

Risques acceptés / personne et date de validation :

Prochaine date de relecture :

## Brief pour un agent IA

Contexte : [produit, écran, public, plateforme].
Ressources autorisées : [noms, URLs officielles, versions et licences approuvées].
Décisions à respecter : [tokens, police, icônes et composants retenus].
Ne pas ajouter de dépendance, de fichier tiers, de couleur ou d’achat sans accord.
Signaler les noms d’API ou d’icônes introuvables au lieu de les inventer.
Préparer les états vide, chargement, erreur et succès ; maintenir le clavier et le focus.
Séparer ce qui est implémenté, testé automatiquement et encore à vérifier par une personne.
Ne pas utiliser les ressources tierces pour entraîner un modèle ni constituer un pack.
Avant livraison : lister les fichiers modifiés, les sources, les tests et les limites.

## Guides UX/UI gratuits

https://joyccelight-playbook.uxplay.workers.dev/fr/articles?utm_source=repertoire-ui-ux&utm_medium=worksheet&utm_campaign=ressource-gratuite

Les conditions de LICENCES-FR.txt s’appliquent. Cette fiche ne constitue pas une certification d’accessibilité ni une validation juridique.
