# Livres UI/UX gratuits : kit de publication FR/EN

## À charger dans Gumroad

- Produit français : `01-FICHIERS-CLIENTS/FR/Repertoire-UI-UX-Gratuit-FR.zip`.
- English product: `01-FICHIERS-CLIENTS/EN/Free-UI-UX-Directory-EN.zip`.

Chaque ZIP client contient 7 fichiers dans une seule langue. Ne chargez pas cette archive générale comme contenu d’un produit : elle contient aussi les documents de publication.

## À relire

`02-LIVRES-PDF/` contient les deux livres directement accessibles : **54 pages chacun, 51 fiches, 6 familles, 75 liens et 20 captures cliquables**. Chaque livre est aussi dans son ZIP client, avec une fiche de décision de 3 pages, deux Markdown, un CSV, un mode d’emploi et les notices.

Les 20 captures sont partagées entre les deux éditions, pas 40 captures différentes. Les interfaces restent dans leur langue d’origine. La sélection est partielle ; les 75 liens restent présents. Une capture de chargement a été écartée des 21 originaux reçus. Aucun aperçu n’a été inventé et aucun nouvel appel de capture n’a été lancé.

## Pour publier

`03-PUBLICATION-GUMROAD/FR/` et `EN/` contiennent chacun :

- le nom, le résumé, la description et les messages à copier ;
- le guide de publication et de test à 0 ;
- une couverture 1280 × 720 et un thumbnail 1080 × 1080, avec le prix **0 $ / $0**.

Aucun produit n’a été publié par cet agent. Les règles actuelles de Gumroad doivent être vérifiées dans le compte ; tester les deux parcours à 0 avant de les partager. Retirer les consignes internes du texte public.

## Site et liens attendus

Les pages, téléchargements et promotions du répertoire sont retirés du code du site. Leurs images sont conservées. Aucun teaser ou téléchargement de repli n’est prévu. Les quatre guides éditoriaux par langue et le Playbook payant sont conservés. Un changement local n’est pas une preuve de retrait en production.

**Transmettre les deux vraies URL publiques Gumroad FR/EN après publication et test pour ajouter les redirections dans une prochaine modification.** Aucun lien de produit gratuit n’est inventé dans ces fichiers.

Chaque livre se termine par le Playbook payant localisé : 182 pages FR / 171 pages EN, 120 sections, 77 règles, kit de 26 pages et 12 fiches, archive de 21 fichiers dans la langue achetée, 29 USD en paiement unique. Ces fichiers payants ne sont pas inclus.

## Contrôles et limites

`CONTENU-VERIFIE.json` décrit les fichiers livrés. `SHA256SUMS.txt` permet de vérifier leur intégrité. Les images et PDF ont été relus ; cela ne constitue ni un audit des 75 sites, ni une certification d’accessibilité ou PDF/UA. Les dates de capture sont déclarées par la soumission externe, non vérifiées indépendamment. Les captures ne sont pas des actifs à extraire et réutiliser.

Contact : joynagassi@gmail.com
