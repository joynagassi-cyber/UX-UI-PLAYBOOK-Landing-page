# Your free UI/UX Directory

Thank you for downloading this resource by Joy N. / Joyccelight.

**51 entries · 6 categories · 75 resource links · English-language files**

- Free-UI-UX-Directory-EN.pdf: 54-page illustrated A4 guide, 20 screenshots and clickable links.
- Free-UI-UX-Directory-EN.md: entries and links as editable text; screenshots appear only in the PDF.
- UI-UX-Decision-Worksheet-EN.pdf: 3 printable A4 pages; not an interactive PDF form.
- UI-UX-Decision-Worksheet-EN.md: a worksheet to duplicate and complete in a Markdown editor.
- UI-UX-Selection-Grid-EN.csv: 6 category rows to complete in a spreadsheet (UTF-8, comma-separated).
- LICENSES-EN.txt: guide terms and Domine/Lucide notices.

Start with one screen, compare a few options and record why you chose them. Third-party services have their own prices and licenses. This download includes none of their asset packs or libraries. The destinations have not undergone an exhaustive availability audit.

Version 1.0 · English edition · November 18, 2026
Free guides: https://joyccelight-playbook.uxplay.workers.dev/en/articles?utm_source=ui-ux-directory&utm_medium=readme&utm_campaign=free-resource
Paid English Playbook (separate product, $29 USD): https://joyccelight.gumroad.com/l/uxuiplaybook

Contact: joynagassi@gmail.com
