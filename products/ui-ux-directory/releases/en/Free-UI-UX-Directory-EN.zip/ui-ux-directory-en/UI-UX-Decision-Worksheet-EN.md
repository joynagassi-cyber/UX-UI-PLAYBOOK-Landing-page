# UI/UX decision worksheet

Version 1.0 · English · Joy N. / Joyccelight · November 18, 2026

Duplicate for each project. Blank lines are fields to complete, not decisions that have already been approved.

## 1. The project

- Project / screen:
- Audience and main task:
- Platform, framework and versions:
- Constraints (budget, data, hosting, devices):
- Responsible person / date:

## 2. The choices

Compare no more than two options per category. Record a decision, including “no new tool” where appropriate.

### Colors and themes

Which text/background pairs remain readable in both themes?

- Option A / official URL:
- Option B / official URL:
- Decision and reason:
- Version, license and attribution:
- Cost / constraint / limitation:
- Completed check and result:
- Remaining check / responsible person / date:

### Typography

Do accents, numbers, long labels and hosting conditions fit?

- Option A / official URL:
- Option B / official URL:
- Decision and reason:
- Version, license and attribution:
- Cost / constraint / limitation:
- Completed check and result:
- Remaining check / responsible person / date:

### Icons

Do the names exist, and do important actions keep their text labels?

- Option A / official URL:
- Option B / official URL:
- Decision and reason:
- Version, license and attribution:
- Cost / constraint / limitation:
- Completed check and result:
- Remaining check / responsible person / date:

### Components and kits

Which behaviors and updates will become your responsibility?

- Option A / official URL:
- Option B / official URL:
- Decision and reason:
- Version, license and attribution:
- Cost / constraint / limitation:
- Completed check and result:
- Remaining check / responsible person / date:

### Data charts

Does the chart have units, a legend and a text alternative?

- Option A / official URL:
- Option B / official URL:
- Decision and reason:
- Version, license and attribution:
- Cost / constraint / limitation:
- Completed check and result:
- Remaining check / responsible person / date:

### Illustrations and 3D

Does the illustration convey information rather than obstruct loading?

- Option A / official URL:
- Option B / official URL:
- Decision and reason:
- Version, license and attribution:
- Cost / constraint / limitation:
- Completed check and result:
- Remaining check / responsible person / date:

## 3. Before integration

- [ ] Identify official sources and authors; read each selected file's license.
- [ ] Check rights to modify, host and deliver files to a client.
- [ ] Accept costs, quotas and attribution requirements.
- [ ] Do not send personal data or client files to a service without approval.
- [ ] Do not scrape or redistribute third-party packs, or use AI in ways prohibited by a license.

## 4. Before delivery

- [ ] Examine empty, loading, error and success states.
- [ ] Test keyboard access, focus, zoom and a narrow screen.
- [ ] Examine actual contrast and text alternatives.
- [ ] Measure file weight and loading in the project instead of repeating marketing figures.
- [ ] Verify AI-suggested imports, icon names, APIs and versions.

Test results / link to evidence:

Decision (accepted / revisit / rejected):

Accepted risks / approving person and date:

Next review date:

## Brief for an AI agent

Context: [product, screen, audience, platform].
Approved resources: [names, official URLs, versions and accepted licenses].
Decisions to follow: [selected tokens, typeface, icons and components].
Do not add dependencies, third-party files, colors or purchases without approval.
Flag missing API or icon names instead of inventing them.
Prepare empty, loading, error and success states; preserve keyboard access and focus.
Separate implemented work, automated checks and remaining human review.
Do not use third-party resources to train a model or assemble an asset pack.
Before delivery: list changed files, sources, tests and limitations.

## Free UX/UI guides

https://joyccelight-playbook.uxplay.workers.dev/en/articles?utm_source=ui-ux-directory&utm_medium=worksheet&utm_campaign=free-resource

The terms in LICENSES-EN.txt apply. This worksheet is not an accessibility certification or legal validation.
