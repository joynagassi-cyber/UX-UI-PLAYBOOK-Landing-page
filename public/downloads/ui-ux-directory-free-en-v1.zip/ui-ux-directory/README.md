# Your free UI/UX Directory

Thank you for downloading this resource by Joy N. / Joyccelight.

**51 entries · 6 categories · 75 resource links · English-language files**

- ui-ux-directory-en.pdf: 34-page A4 guide with clickable links.
- ui-ux-directory-en.md: the same editorial guide as editable text.
- decision-worksheet.pdf: 3 printable A4 pages; not an interactive PDF form.
- decision-worksheet.md: a worksheet to duplicate and complete in a Markdown editor.
- selection-grid.csv: 6 category rows to complete in a spreadsheet (UTF-8, comma-separated).
- LICENSES.txt: guide terms and Domine/Lucide notices.

Start with one screen, compare a few options and record why you chose them. Third-party services have their own prices and licenses. This download includes none of their asset packs or libraries. The destinations have not undergone an exhaustive availability audit.

Version 1.0 · English edition · November 18, 2026
Guide page: https://joyccelight-playbook.uxplay.workers.dev/en/resources/ui-ux-directory?utm_source=ui-ux-directory&utm_medium=readme&utm_campaign=free-resource
Free articles: https://joyccelight-playbook.uxplay.workers.dev/en/articles?utm_source=ui-ux-directory&utm_medium=readme&utm_campaign=free-resource
Paid Playbook (separate product): https://joyccelight-playbook.uxplay.workers.dev/en?utm_source=ui-ux-directory&utm_medium=readme&utm_campaign=free-resource#buy

Contact: joynagassi@gmail.com
